package com.rectangle;

import java.util.Scanner;

public class Rectangle 
{
	   public static void main(String args[]) 
	   {
		   // Rectangle object 1
	        Rectangle r1 = new Rectangle();
	        r1.input();
	        r1.calculate();
	        r1.display();
	        
			// Rectangle object 2
	        Rectangle r2 = new Rectangle();
	        r2.input();
	        r2.calculate();
	        r2.display();
	        
			   // Rectangle object 3
	        Rectangle r3 = new Rectangle();
	        r3.input();
	        r3.calculate();
	        r3.display();
	        
			   // Rectangle object 4
	        Rectangle r4 = new Rectangle();
	        r4.input();
	        r4.calculate();
	        r4.display();
	        
			   // Rectangle object 5
	        Rectangle r5 = new Rectangle();
	        r5.input();
	        r5.calculate();
	        r5.display();
	}

		float length; 
	    float breadth; 
	    float area; 
	   
	    public Rectangle()
	    {
	    	length = 0;
	    	breadth= 0;
	    }

	    void input() 
	    {
	        Scanner scan = new Scanner(System.in);
	        System.out.print("Enter length of rectangle : ");
	        length = scan.nextInt();
	        System.out.print("Enter breadth of rectangle : ");
	        breadth = scan.nextInt();
	    }

	    void calculate() 
	    {
	        area = length * breadth;
	        
	    }

	    void display() 
	    {
	        System.out.println("Area of Rectangle is = " + area);
	       
	    }
}
