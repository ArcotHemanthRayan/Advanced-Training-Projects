package com.string;

import java.util.Stack;
import java.util.regex.Pattern;

public class StringHandling 
{
public static void main(String[] args) {
			
		
		String s= "JAVA is Simple";
		
		//UpperCase Transform
		System.out.println(s.toUpperCase()); 
		
		//LowerCase Transform
		System.out.println(s.toLowerCase()); 
		
		// First letter of words
		String[] words=s.split("\\s");	
		for(String w:words){  
			System.out.print(w.charAt(0)); 
			System.out.print(" ");
		}
		System.out.println(" ");
		
		//Reversing Words
        System.out.println(reverseWords(s));

        //Reversing each letter in same word
        reverseWords1(s);

        System.out.println(" ");
        System.out.println(s.length());
		}

  static String reverseWords(String str)
   {

    Pattern pattern = Pattern.compile("\\s");
    String[] temp = pattern.split(str);
    String result = "";

    for (int i = 0; i < temp.length; i++) 
    {
        if (i == temp.length - 1)
            result = temp[i] + result;
        else
            result = " " + temp[i] + result;
    }
    return result;
}
  static void reverseWords1(String str)
  {
      Stack<Character> st=new Stack<Character>();
      for (int i = 0; i < str.length(); ++i) {
          if (str.charAt(i) != ' ')
              st.push(str.charAt(i));
    
          else {
              while (st.empty() == false) {
                  System.out.print(st.pop());
                   
              }
              System.out.print(" ");
          }
      }
    
      while (st.empty() == false) {
          System.out.print(st.pop());
           
      }
  }
}
