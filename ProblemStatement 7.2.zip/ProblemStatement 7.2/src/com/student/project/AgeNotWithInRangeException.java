package com.student.project;

public class AgeNotWithInRangeException extends Exception
{
	public String toString()
    {
         return ("Age Is Not In The Specified Limit");
    }
}
