package com.student.project;

public class NameNotValidException extends Exception {

	public static void main(String[] args) 
	{
		System.out.println("Name Is Not Valid");
	}

}
