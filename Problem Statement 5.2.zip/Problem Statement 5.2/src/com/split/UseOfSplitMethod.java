package com.split;

public class UseOfSplitMethod 
{
	public static void main(String[] args) {
		
		
		String s= (" 23  +  45  -  (  343  /  12  ) ");
		String[] s1=s.split("\\s");
		
		for(String s2:s1){  
			System.out.println(s2); 
		}
	}
}
