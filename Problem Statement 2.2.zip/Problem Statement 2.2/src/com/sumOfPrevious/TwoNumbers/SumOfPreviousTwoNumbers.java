package com.sumOfPrevious.TwoNumbers;

import java.util.Scanner;

public class SumOfPreviousTwoNumbers 
{

	public static void main(String[] args) 
	{
		Scanner scan=new Scanner(System.in);
		
		System.out.println("Enter First Number : ");
		int n1=scan.nextInt();
		
		System.out.println("Enter Second Number : ");
		int n2=scan.nextInt();
		
		int n3;    
		 System.out.print(n1+" "+n2);    
		    
		 for(int i=1;i<=13;i++)   
		 {    
		  n3=n1+n2;    
		  System.out.print(" "+n3);    
		  n1=n2;    
		  n2=n3;    
		 }
	}

}
