package com.arrayList;

import java.util.Collections;
import java.util.Scanner;

public class ArrayList 
{
	public static void main (String[] args) 
	{
	 java.util.ArrayList<String> a1=new java.util.ArrayList<String>();
	 int n;
	 System.out.println("Enter Number Of Students To Store :");
	 Scanner scan= new Scanner(System.in);
	 n=scan.nextInt();
	 System.out.println("Enter Student Names:");
	for(int i=0;i<n;i++)
	{
		a1.add(scan.next());
	}
	System.out.println("Students In The List Are :"+a1);
	for(String a:a1)
	{
			System.out.println("Enter the name of the student to be searched:");
		    String st=scan.next(); 
		    int position=Collections.binarySearch(a1,st);
			System.out.println("posistion of"+st+"is:"+position);
			
			}
	 }
}

