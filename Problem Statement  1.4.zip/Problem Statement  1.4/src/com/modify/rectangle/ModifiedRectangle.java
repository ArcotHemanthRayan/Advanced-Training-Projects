package com.modify.rectangle;

import java.util.Scanner;

public class ModifiedRectangle 
{

	public static void main(String[] args) 
	{
		//rectangle object 1
		ModifiedRectangle r1 = new ModifiedRectangle();
        r1.input();
        r1.areaRectangle();
        r1.perimeterRectangle();
        r1.display();
        
        //rectangle object 2
        ModifiedRectangle r2 = new ModifiedRectangle();
        r2.input();
        r2.areaRectangle();
        r2.perimeterRectangle();
        r2.display();
        
        //rectangle object 3
        ModifiedRectangle r3 = new ModifiedRectangle();
        r3.input();
        r3.areaRectangle();
        r3.perimeterRectangle();
        r3.display();
        
        //rectangle object 4
        ModifiedRectangle r4 = new ModifiedRectangle();
        r4.input();
        r4.areaRectangle();
        r4.perimeterRectangle();
        r4.display();
        ModifiedRectangle r5 = new ModifiedRectangle();
        r5.input();
        
        //rectangle object 5
        r5.areaRectangle();
        r5.perimeterRectangle();
        r5.display();
	}
	
	float length; 
    float width; 
    float area; 
    float perimeter;
    
    public void setLength(int length) 
    {
		this.length = length;
	}
    
    public float getLength() 
    {
		return length;
	}

    public void setWidth(int width) 
    {
		this.width = width;
	}

	public float getWidth() 
	{
		return width;
	}

	
    public ModifiedRectangle()
    {
    	length = 1;
    	width= 1;
    }

    void input() 
    {
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter length of rectangle: ");
        length = scan.nextInt();
        System.out.print("Enter width of rectangle: ");
        width = scan.nextInt();
    }
    
    void  areaRectangle()
    {
        area = length * width;
       
    }
 
     void  perimeterRectangle()
    {
    	 perimeter = 2*(length + width);
       
    }

    void display() 
    {
    	if(length>0.0 && length<20.0)
        {
        System.out.println("Area of Rectangle is = "+area);
        System.out.println("Perimeter of Rectangle is = "+perimeter);
        }
       
     }

}
