package com.stringSuffle;

import java.util.Scanner;

public class StringSuffle 
{
	public static void main(String[] args)
	{
		Scanner S=new Scanner(System.in);
		System.out.print("First=");
		String a=S.nextLine();
		System.out.print("and ");
		System.out.print("Second= ");
		String b=S.nextLine();
		System.out.print("and ");
		System.out.print("Third= ");
		String c=S.nextLine();		
		

		if (stringSuffle(a, b, c)) 
		{
			System.out.print("true : third string is valid shuffle of first and second string.");
		}
		else 
		{
			System.out.print("false : third string is NOT a valid shuffle of first and second string.");
		}
	}
	
	public static boolean stringSuffle(String a, String b, String c)
	{
		
		if (a.length() == 0 && b.length() == 0 && c.length() == 0) {
			return true;
		}

		if (c.length() == 0) {
			return false;
		}


		boolean x = (a.length() != 0 && c.charAt(0) == a.charAt(0)) &&
				stringSuffle(a.substring(1), b, c.substring(1));


		boolean y = (b.length() != 0 && c.charAt(0) == b.charAt(0)) &&
				stringSuffle(a, b.substring(1), c.substring(1));

		return x || y;
	}
}
