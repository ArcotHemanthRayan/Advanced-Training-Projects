package com.coins;

import java.util.Scanner;
import java.util.Vector;

public class CoinsProgram 
{
	 public static void main(String[] args) 
	    {
	    	 Scanner scan=new Scanner(System.in);
	    	   System.out.println("Enter Amount");
	    	   int n=scan.nextInt();
	        
	    	   
	        System.out.print("BreakDown- " );
	        findMin(n);
	    }
	 
	static int coinsProgram[] = {1, 2, 5, 10, 20, 50, 100, 500, 2000};
		    
		    static int n = coinsProgram.length;
		  
		    static void findMin(int a)
		    {
		   	        Vector<Integer> ans = new Vector<>();
		  
		       	        for (int i = n - 1; i >= 0; i--)
		        {
		           
		            while (a >= coinsProgram[i]) 
		            {
		                a -= coinsProgram[i];
		                ans.add(coinsProgram[i]);
		            }
		        }
		  
		        
		        for (int i = 0; i < ans.size(); i++)
		        {
		            System.out.print("Rs" + ans.elementAt(i)+" +");
		        }
		    }
}
