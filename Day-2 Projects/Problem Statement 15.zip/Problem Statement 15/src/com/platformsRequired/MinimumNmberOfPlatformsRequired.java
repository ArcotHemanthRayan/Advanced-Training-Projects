package com.platformsRequired;

import java.util.Arrays;

public class MinimumNmberOfPlatformsRequired 
{
	 public static void main(String[] args)
	    {
	        int arr[] = { 900, 940, 950, 1100, 1500, 1800 };
	        int dep[] = { 910, 1200, 1120, 1130, 1900, 2000 };
	        int n = arr.length;
	        System.out.println("Minimum Number of Platforms Required = "+ findingPlatForms(arr, dep, n));                   
	    }
	 
	static int findingPlatForms(int arr[], int dep[], int n)
    {
        Arrays.sort(arr);
        Arrays.sort(dep);
 
        // plat_needed indicates number of platforms needed at a time
        
        int platformNeeded = 1, result = 1;
        int i = 1, j = 0;
 
        while (i < n && j < n) 
        {
            if (arr[i] <= dep[j]) 
            {
            	platformNeeded++;
                i++;
            }
 
            // Else decrement count of platforms needed
            else if (arr[i] > dep[j]) 
            {
            	platformNeeded--;
                j++;
            }
 
            // Update result
            if (platformNeeded > result)
                result = platformNeeded;
        }
 
        return result;
    }
 
}
