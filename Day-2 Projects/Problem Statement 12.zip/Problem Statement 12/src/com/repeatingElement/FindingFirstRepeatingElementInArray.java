package com.repeatingElement;

import java.util.HashSet;

public class FindingFirstRepeatingElementInArray 
{
	public static void main (String[] args) throws java.lang.Exception
    {
        int array[] = { 1, 2, 3, 10, 2, 4, 5, 7, 8 };
        firstRepeatingElementInArray(array);
    }
	
	static void firstRepeatingElementInArray(int array[])
    {
        // Initialize index of first repeating element
        int min = -1;
 
        HashSet<Integer> set = new HashSet<>();
 
        for (int i=array.length-1; i>=0; i--)
        {
            // If element is already in hash set, update min
            if (set.contains(array[i]))
                min = i;
 
            else   
                set.add(array[i]);
        }
        
        
 
        // Print the result
        if (min != -1)
          System.out.println("First Repeated Element Is : " + array[min]);
        else
          System.out.println("There Is No Repeating Elements In The Given Array");
    }
}
