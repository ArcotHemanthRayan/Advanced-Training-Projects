package com.book;

public class Book 
{
	public void createBooks() 
	{
		SettersAndGettersOfBook book[] = new SettersAndGettersOfBook[2];		 
	    book[0] = new SettersAndGettersOfBook("Java Programing ", 350.50);
	    book[1] = new SettersAndGettersOfBook("Let Us C", 200.00);
	    for(int i = 0; i<book.length; i++) 
	    {
		    book[i].display();
		    System.out.println(" ");
	    }
	    
	      }
	
	public void showBooks() 
	{
		  	createBooks();
		
	}
	public static void main(String args[])  
	{
	    Book c1 = new Book();  
		c1.showBooks();
	   
	}

}
