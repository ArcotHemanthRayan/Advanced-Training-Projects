package com.arrays;

public class ArrayOperations 
{
	static int A[] = {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};
	public static void main(String[] args) 
	{
		System.out.println("Sum Of Array Numbers From index 0 - 14 is : "+sum());
		
		System.out.println("");
		
	}
	static int sum()
    {
        int sum = 0; // initialize sum
        int i;
  
        for (i = 0; i <=14; i++)
            sum += A[i];
  
        return sum;
    }

}
