package com.string.operations;

public class StringOperations 
{
	 public static void main(String[] args)
	    {
	        String  s = new String("MPHASIS");
	        printRotatedString(s);
	        System.out.println("MPHASIS");
	    }
    static void printRotatedString(String s)
    {
        int len = s.length();
        StringBuffer sbuffer;
         
        for (int i = 0; i < len; i++)
        {
        	sbuffer = new StringBuffer();
             
            int j = i;  
            int k = 0;  
      
            for (int k1 = j; k1 < s.length(); k1++) {
            	sbuffer.insert(k, s.charAt(j));
                k++;
                j++;
            }
      
            j = 0;
            while (j < i)
            {
            	sbuffer.insert(k, s.charAt(j));
                j++;
                k++;
            }
      
            System.out.println(sbuffer);
        }
    }
    
}
