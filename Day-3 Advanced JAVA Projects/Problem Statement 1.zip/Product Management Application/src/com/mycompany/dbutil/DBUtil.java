package com.mycompany.dbutil;
import java.sql.*;

public class DBUtil {
	 private static Connection connection;
    public static Connection getConnection()
    {
      
        try{
        	
        	//path for connecting to database
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/productdb", "root", "Hemanth@12");
           
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
       return connection;
    }

    //closing connection connection
    public static void closeConnection(Connection conn)
    {
        try{
            conn.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }


}