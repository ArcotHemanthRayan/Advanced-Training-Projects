package com.mycompany.domain;
public class Product 
{

	String product_id;
    String product_name;
    int product_price;

    public Product()
    { }

    public Product(String product_id, String product_name, int product_price) 
    {
        this.product_id = product_id;
        this.product_name = product_name;
        this.product_price = product_price;
    }

    // Getters and Setters of product class
    public String getProductid() 
    {
        return product_id;
    }

    public void setProductid(String productid) 
    {
        this.product_id = productid;
    }

    public String getProductName() 
    {
        return product_name;
    }

    public void setProductName(String productName) 
    {
        this.product_name = productName;
    }

    public int getProductPrice() 
    {
        return product_price;
    }

    public void setProductPrice(int productPrice) 
    {
        this.product_price = productPrice;
    }

    @Override
    public String toString()
    {
        return "Product [productid=" + product_id + ", productName=" + product_name + ", productPrice=" + product_price + "]";
    }

}