package com.medicine;

public class MedicineProject
{
	public void displayLabel()
	{
		System.out.println("Company : Bharath Biotech");
	}
}
class Tablet extends MedicineProject
{
	public void displayLabel()
	{
		System.out.println("Store in a cool dry place");
	}
}
class Syrup extends MedicineProject
{
	public void displayLabel()
	{
		System.out.println("Consumption as directed by The Physician");
	}
}
class Ointment extends MedicineProject
{
	public void displayLabel()
	{
		System.out.println("For external use only");
	}
}
