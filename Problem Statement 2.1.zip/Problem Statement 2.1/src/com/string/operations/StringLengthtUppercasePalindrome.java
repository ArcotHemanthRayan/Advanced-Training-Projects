package com.string.operations;

import java.util.Scanner;

public class StringLengthtUppercasePalindrome 
{

	public static void main(String[] args) 
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter A String");
		String s=scan.nextLine();
		
		// Calculating length of string
		System.out.println("The Length Of The String Is : "+s.length());
		
		// String to uppercase
		System.out.println("The Entered String To Uppercase : "+s.toUpperCase());
		
		//checking the entered string is an palindrome or not
		
		if(palindrome(s))
			System.out.println("The Entered String Is An Palindrome");
		else
			System.out.println("The Entered String Is Not An Palindrome");
		
	}
	//palindrome
	static boolean palindrome(String s)
	{
		  int i = 0, j = s.length() - 1;
		  
	        while (i < j) {
	 
	            if (s.charAt(i) != s.charAt(j))
	                return false;
	 
	            i++;
	            j--;
	        }
	 
	        return true;
	    }
	

}
