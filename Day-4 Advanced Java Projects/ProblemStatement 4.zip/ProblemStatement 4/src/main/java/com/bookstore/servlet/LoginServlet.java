package com.bookstore.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bookstore.dao.*;
import com.bookstore.entity.*;
import com.bookstore.db.*;

package com.bookstore;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class LoginServlet extends HttpServlet 
{
       
    public LoginServlet() 
    {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out=response.getWriter();
		String useruname=request.getParameter("user_name");
		String userpassword=request.getParameter("password");
		
		UserDao dao= new UserDao(DbConnection.getConnection());
		
		User user=dao.getUserByUnameAndPassword(useruname, userpassword);
		
		if(user==null) {
			
			out.println("Wrong Login!!!!...... Try again");
			
			HttpSession s=request.getSession();
			
			response.sendRedirect("Login.jsp");
			
			
		}
		else {
			// login successfull
			
			HttpSession s=request.getSession();
			s.setAttribute("currentUser", user);
			response.sendRedirect("Welcome.jsp");
			
		}
		
		
		
		
	}

}

