package com.bookstore.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Timestamp;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bookstore.*;
import com.bookstore.dao.UserDao;
import com.bookstore.entity.*;
import com.bookstore.db.*;

@MultipartConfig
public class RegisterServlet extends HttpServlet 
{
       
    public RegisterServlet() 
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out= response.getWriter();
		response.setContentType("text/html");
		
		
			String first_name=request.getParameter("first_name");
			String address=request.getParameter("address");
			String email=request.getParameter("email");
			String user_name=request.getParameter("user_name");
			String password=request.getParameter("password");
			
			User user=new User(first_name, address,  email,  user_name,  password);
			UserDao dao=new UserDao(DbConnection.getConnection());
			if(dao.saveUser(user)) 
			{
				out.println("Register");
				response.sendRedirect("Login.jsp");

			}
			else 
			{
				out.println("Failed to Register");
			}
		}
		
	
	}



